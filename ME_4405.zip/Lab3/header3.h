/*
 * header3.h
 *
 *  Created on: Feb 15, 2023
 *      Author: parth
 */

#ifndef HEADER3_H_
#define HEADER3_H_

#define LED_RED GPIO_PIN0//define pins for first LED
#define LED2 GPIO_PIN2|GPIO_PIN1|GPIO_PIN0//define pins for second LED

int getState(LED_STATE);//function prototype




#endif /* HEADER3_H_ */
