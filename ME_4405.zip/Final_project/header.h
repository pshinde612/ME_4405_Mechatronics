/*
 * header.h
 *
 *  Created on: Apr 23, 2023
 *      Author: parth
 */

#ifndef HEADER_H_
#define HEADER_H_
// Sets PWM period.
#define periodPWM 10000

// Function definitions.
float getPID();




#endif /* HEADER_H_ */
