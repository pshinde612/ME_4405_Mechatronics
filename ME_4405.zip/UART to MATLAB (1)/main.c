/* =====================================================

   Fundamentals of Mechatronics
   Example Code: Sending ADC data to MATLAB over UART
   Author: Frank L. Hammond III

   Program to acquire ADC data from P5.5 and transmit
   over UART to a serial comm device. In this case, the
   serial comm is a PC and the serial monitor is MATLAB,
   which can be configured to read UART data and plot
   them in real-time using the file MSP432UARTComm.m  

======================================================= */

#include "msp.h"
#include "driverlib.h"

// Declare variables for sensor data
volatile float voltage;
volatile uint16_t temp = 0 ;

// Initialize UART Configuration, Timer_A module, ADC module, and associated interrupts…
const eUSCI_UART_Config UART_init =
{
 EUSCI_A_UART_CLOCKSOURCE_SMCLK,
 3,
 4,
 2,
 EUSCI_A_UART_NO_PARITY,
 EUSCI_A_UART_LSB_FIRST,
 EUSCI_A_UART_ONE_STOP_BIT,
 EUSCI_A_UART_MODE,
 EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION
};

const Timer_A_UpModeConfig upConfig_0 =
{
 TIMER_A_CLOCKSOURCE_SMCLK,        //Setting up a 3MHz clock
 TIMER_A_CLOCKSOURCE_DIVIDER_6,
 5000,   // Choose an appropriate period for your data transfer (here, 10 Hz)
 TIMER_A_TAIE_INTERRUPT_DISABLE,
 TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,
 TIMER_A_DO_CLEAR
};


void main(){
    WDT_A_holdTimer();              // Stop watchdog timer
    CS_setDCOFrequency(3E+6);       // Set clock frequency to 3MHz
    CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);

    // Disable All Interrrupts
    Interrupt_disableMaster();

    /////*** Analog to Digital Conversion Configuration ***/////
    // Enable ADC module
    ADC14_enableModule();
    // Set functionality of pin P5.5
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P5,GPIO_PIN5,GPIO_TERTIARY_MODULE_FUNCTION);
    // Set to 14 bit resolution
    ADC14_setResolution(ADC_14BIT);
    // Tie to SMCLK with no divider
    ADC14_initModule(ADC_CLOCKSOURCE_SMCLK,ADC_PREDIVIDER_1,ADC_DIVIDER_1, false);
    // Place result of conversion in ADC_MEM0 register. We will trigger each conversion manually
    ADC14_configureSingleSampleMode(ADC_MEM0, false);
    // Sample Channel 0 to register ADC_MEM0.  Use 0-2.5V range.
    ADC14_configureConversionMemory(ADC_MEM0, ADC_VREFPOS_AVCC_VREFNEG_VSS, ADC_INPUT_A0, false);
    // We will trigger each conversion manually
    ADC14_enableSampleTimer(ADC_MANUAL_ITERATION);

    ///// *** Set up timer *** /////
    Timer_A_configureUpMode(TIMER_A0_BASE,&upConfig_0);  // Configure Timer A using above struct
    Interrupt_enableInterrupt(INT_TA0_0);   // Enable Timer A interrupt
    Timer_A_startCounter(TIMER_A0_BASE, TIMER_A_UP_MODE);  // Start Timer A

    // Start ADC process
    ADC14_enableConversion();        // Sets the ENC bit
    ADC14_toggleConversionTrigger(); // Sets the SC bit (trigger)

    // Configure P1.2 and P1.3 as UART TX/RX
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN2 | GPIO_PIN3, GPIO_PRIMARY_MODULE_FUNCTION);

    // Initialize UART Module 0
    UART_initModule(EUSCI_A0_BASE, &UART_init);
    UART_enableModule(EUSCI_A0_BASE);

    // Enable the UART receive interrupt at the peripheral level
    UART_enableInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
    Interrupt_enableInterrupt(INT_EUSCIA0);

    // Enable NVIC
    Interrupt_enableMaster();

    while(1){

    }
}

void TA0_0_IRQHandler(void)
{
    char data[8]; // Large enough to hold the ASCII transcription of data, to be sent to Matlab
    int i = 0; // for-loop index
    int j = 0; // for-loop index

    ADC14_toggleConversionTrigger();    // Trigger the S/H conversion

    while(ADC14_isBusy()) {}        // Wait for conversion to finish
    temp = ADC14_getResult(ADC_MEM0); // get the digital output from the ADC
    voltage = temp * (3.3/16383.0);   // Scale/transform data appropriately

    char ascii_version[8];
    sprintf(ascii_version, "%.4f",voltage);
    for(i=0; i <= 8; i++){
        while((UCA0IFG & 0x0002) == 0x0000){} // Wait until TXBUF is empty
        UART_transmitData(EUSCI_A0_BASE, ascii_version[i]);
    }
    while((UCA0IFG & 0x0002) == 0x0000){} // Wait until TXBUF is empty
    UART_transmitData(EUSCI_A0_BASE, 0xA); // the newline, or "LF" is the default terminal character Matlab looks for to group values together

    Timer_A_clearCaptureCompareInterrupt(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_0);
}