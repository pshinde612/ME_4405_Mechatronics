% =====================================================================
%
% ME 4405 Fundamentals of Mechatronics
% Example Code: Receiving data throught UART in MATLAB
%
% Program to configure P2.4-P2.7 on the MSP432 to
% control four-phase unipolar stepper motor actuation.
% ADC input from a potentiometer adjusts the Timer A
% frequency to control motor angular velocity. P4.0
% is a digital input (pull-down) used to change the
% direction of rotation. The header file contains
% functions for  

%% Serial Communication Parameters
baudRate = 57600;   % UART baud rate
testLength = 30;     % (sec)
transFreq = 1000;      % Set the period in the MSP code to match transmit frequency (Hz)
tInc = 1/transFreq; 
numsamples = transFreq*testLength;   % Cuts off UART after ~5 seconds for this example 
bufLen = 1; %10;    % data plotting buffer length
dataPoints = 1;     % number of data points being transmitted
 
%% Data plotting variables
dataBuf = zeros(bufLen,dataPoints+1); % temporary data storage (used between plot updates)
data = zeros(numsamples,dataPoints + 1); % full data storage array
windowSize = 100; % x-axis viewing window, in number of samples

%% Initialize time stamp recording for real-time plotting
time = zeros(numsamples,1);
j = 1;

strFormat = ''; % data-scanning string format
for i = 1:dataPoints
    strFormat = strcat(strFormat,' %f');
end
 
% s = serial('/dev/tty.usbmodemM4321001'); % Mac
s = serial('COM5'); % PC
set(s,'BaudRate',baudRate);
fopen(s);

% Set up plot
sensor1 = animatedline(0,0,'Color','b','LineWidth',2);
xlabel('Time (seconds)')
ylabel('Potentiometer Voltage (V)')
legend('Potentiometer 1');
title('Example real-time graph')
ylim([0 3.3])
grid on
grid minor
 
% flush any initial data
pause(1)
out = fscanf(s);
flushinput(s);
pause(tInc)
 
%% Begin recording
fprintf('begin recording\n');
tic;
timerval = tic; % Start time = 0

%% loop & read received data
count = 0; % loop count
for i = 1:numsamples
    count = count + 1;          % increment count
    dataBuf(count,1) = toc;     % add time to data buffer
    time(j) = toc;
    j = j+1;
 
    [out, numvals] = fscanf(s, strFormat,[dataPoints,1]); % read received data
    dataBuf(count,2:end) = out; % add read data to data buffer
    data(i,:) = [dataBuf(:,1) dataBuf(:,2)]; 
    
    % when count reached, plot new data
    if count == bufLen
        addpoints(sensor1,dataBuf(:,1),dataBuf(:,2))
        drawnow
        count = 0;
    end
    
    if i > windowSize
        axis([(i-windowSize)/transFreq i/transFreq 0 3.3]);
    end
end

fclose(s);
